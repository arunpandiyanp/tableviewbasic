//
//  AppDelegate.h
//  tableview1
//
//  Created by Dinesh Jaganathan on 22/09/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

