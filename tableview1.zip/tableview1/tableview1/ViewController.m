//
//  ViewController.m
//  tableview1
//
//  Created by Dinesh Jaganathan on 22/09/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return 2;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    TableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"pic" forIndexPath:indexPath];
    cell.s1.text=@"hello";
    cell.i1.image=[UIImage imageNamed:@"14.jpg"];
    cell.i2.image=[UIImage imageNamed:@"1.jpg"];
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
