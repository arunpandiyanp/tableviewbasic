//
//  TableViewCell.m
//  tableview1
//
//  Created by Dinesh Jaganathan on 22/09/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "TableViewCell.h"


@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
