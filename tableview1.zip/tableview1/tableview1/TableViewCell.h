//
//  TableViewCell.h
//  tableview1
//
//  Created by Dinesh Jaganathan on 22/09/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
{
    
}
@property (nonatomic,retain)IBOutlet UILabel *s1;
@property (nonatomic,retain)IBOutlet UIImageView *i1;
@property (nonatomic,retain)IBOutlet UIImageView *i2;


@end
